import React, { Component } from "react";

export default class NoMatch extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return <h1>Erreur 404 page non trouvée</h1>;
  }
}
