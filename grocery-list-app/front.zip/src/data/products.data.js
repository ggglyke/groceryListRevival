export default [
  { title: "Pommes", rayon: 1 },
  { title: "Lessive", rayon: 2 },
  { title: "Vin rouge", rayon: 3 },
  { title: "Savon", rayon: 4 },
  { title: "Quinoa", rayon: 5 },
  { title: "Casserole", rayon: 6 },
  { title: "Yaourt", rayon: 7 },
  { title: "Brie", rayon: 12 },
  { title: "Raclette fumée", rayon: 12 },
  { title: "Bleu d'Auvergne", rayon: 12 },
  { title: "Emmental", rayon: 12 },
  { title: "Camembert", rayon: 12 },
  { title: "Sel", rayon: 13 },
  { title: "Poivre", rayon: 13 },
  { title: "Riz basmati", rayon: 15 },
  { title: "Sardines en conserve", rayon: 16 },
  { title: "Papier toilette", rayon: 17 },
  { title: "Eau minérale", rayon: 18 },
  { title: "Céréales", rayon: 19 },
  { title: "Tomates en conserve", rayon: 20 },
];

/*customProducts = [
  {
    title: "Chaussons d'escalade",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Mèches à bougies",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Petit trépied pieds souples",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Repose-tête massage",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Flares audio",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Poêles en inox",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Colonne de salle de bain",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Tablier de cuisine ",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Capote de sac",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Matelas",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Baskets de sport",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "T-shirts de sport",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
  {
    title: "Oreiller Bonsoirs",
    rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
  },
];

db.lists.updateOne(
  { _id: ObjectId("64cce1fbde2b400041b554e4") },
  {
    $set: {
      customProducts: [
        {
          title: "Chaussons d'escalade",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Mèches à bougies",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Petit trépied pieds souples",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Repose-tête massage",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Flares audio",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Poêles en inox",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Colonne de salle de bain",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Tablier de cuisine ",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Capote de sac",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Matelas",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Baskets de sport",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "T-shirts de sport",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
        {
          title: "Oreiller Bonsoirs",
          rayon: ObjectId("656df56fc9e6fb41ec6cca8b"),
        },
      ],
    },
  }
);

db.lists.updateOne(
  { _id: ObjectId("64cce1fbde2b400041b554e4") },
  {
    $set: {
      customProducts: []
    }
  }
);
*/
