module.exports = {
  url:
    "mongodb+srv://ggglyke:trf22mdexofregr@selfdashboard.96rwa.mongodb.net/groceryList?retryWrites=true&w=majority",
};
